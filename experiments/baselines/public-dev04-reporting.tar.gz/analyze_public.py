"""Describe the registered public development sample without inflating its size."""

from __future__ import annotations

import argparse
from collections import Counter
import json
from pathlib import Path


def analyze(bundle, registration):
    label = registration["experiment"]
    arms = registration["arms"]
    tasks = registration["tasks"]
    registered_tasks = {task["task_id"] for task in tasks}
    selected = {}
    errors = []
    for row in bundle["trials"]:
        result = row["result"]
        metadata = (result.get("agent_result") or {}).get("metadata") or {}
        if metadata.get("adapter") != label and not row["job_name"].startswith(f"tb-{label}-"):
            continue
        arm = metadata.get("study_arm") or (((result.get("config") or {}).get("agent") or {}).get("kwargs") or {}).get("arm")
        if arm not in arms:
            raise ValueError("Registered trial has no identifiable comparison arm")
        task_id = result["task_name"].removeprefix("terminal-bench/")
        if task_id not in registered_tasks:
            raise ValueError(f"Unregistered task identity: {result['task_name']}")
        key = (task_id, arm)
        if key in selected:
            raise ValueError(f"Duplicate registered task/arm; do not pick the best: {key}")
        control_id = metadata.get("control_id")
        report = (bundle["model_runs"].get(control_id) or {}).get("report") or {}
        grade = ((result.get("verifier_result") or {}).get("rewards") or {}).get("reward")
        acceptance = (report.get("last_acceptance") or {}).get("verdict")
        valid = row["classification"] == "graded"
        summary = {"task_id": key[0], "upstream_task_name": result["task_name"],
                   "arm": key[1], "classification": row["classification"],
                   "official_raw_reward": grade, "valid_for_comparison": valid,
                   "requests": report.get("used_requests"), "status": report.get("status"),
                   "input_tokens": (result.get("agent_result") or {}).get("n_input_tokens"),
                   "output_tokens": (result.get("agent_result") or {}).get("n_output_tokens"),
                   "cache_tokens": (result.get("agent_result") or {}).get("n_cache_tokens"),
                   "executor_episodes": sum(r["role"] == "executor" for r in report.get("rounds", [])),
                   "review_episodes": sum(r["role"] == "review" for r in report.get("rounds", [])),
                   "episode_seconds": sum(r["seconds"] for r in report.get("rounds", [])),
                   "last_online_verdict": acceptance, "control_id": control_id,
                   "false_online_acceptance": valid and acceptance == "pass" and grade == 0,
                   "artifact_snapshot_available": bool(report.get("artifact_image_id"))}
        selected[key] = summary
        if not valid:
            errors.append(summary)
    paired = Counter()
    for task in tasks:
        native, full = selected.get((task["task_id"], "native")), selected.get((task["task_id"], "sg_v2"))
        if native and full and native["valid_for_comparison"] and full["valid_for_comparison"]:
            paired[f"native_{native['official_raw_reward']:g}_sg_{full['official_raw_reward']:g}"] += 1
    return {"experiment": label, "collected_at": bundle["collected_at"],
            "planned_tasks": len(tasks), "planned_arms": len(arms), "planned_trials": len(registration["planned_order"]),
            "observed_trials": len(selected), "valid_trials": sum(r["valid_for_comparison"] for r in selected.values()),
            "raw_trial_count_including_oracles_and_prior_candidates": len(bundle["trials"]),
            "paired_native_full": dict(paired), "apparatus_or_unresolved": errors,
            "rows": list(selected.values())}


def markdown(summary, registration):
    lookup = {(r["task_id"], r["arm"]): r for r in summary["rows"]}
    lines = [f"# Terminal-Bench 2.1 开发试验：{summary['experiment']}", "",
             f"收据截至 {summary['collected_at']}。已返回 {summary['observed_trials']}/{summary['planned_trials']} 个登记试次，"
             f"其中 {summary['valid_trials']} 个已完成官方测试。不是完整 Terminal-Bench 排行榜成绩，也不是保留集结论。", "",
             "模型为真实 Hermes 0.21.3 + devin/swe-2。六个不同公开 task ID、五组，每组合一次；没有增加随机种子。"
             "全部审查/续跑/重试共享 96 次实际上游请求和官方任务时间上限。并发 1，任务保留官方 1 CPU / 2 GiB；"
             "容器内 Debian APT 改 HTTPS，Harbor 0.24.0，宿主 Python 3.13.5，环境差异已披露。", "",
             "## 官方结果", "", "未运行或尚无结果记为 —；评分装置错误记为待审计，不计作模型失败。", "",
             "| 任务 | 原生 Hermes | 完整 SG | 重发目标 | 无状态补充 | 无审查 |",
             "|---|---:|---:|---:|---:|---:|"]
    for task in registration["tasks"]:
        cells = []
        for arm in registration["arms"]:
            row = lookup.get((task["task_id"], arm))
            cells.append("—" if row is None else str(int(row["official_raw_reward"])) if row["valid_for_comparison"] else "待审计")
        lines.append("| " + " | ".join([task["task_id"], *cells]) + " |")
    lines += ["", "## 机制与实测用量", "",
              "| 任务 / 分组 | 执行轮次 | 审查轮次 | 实际请求 | 输入 / 输出 tokens | 在线终判 |",
              "|---|---:|---:|---:|---:|---|"]
    for task in registration["tasks"]:
        for arm in registration["arms"]:
            row = lookup.get((task["task_id"], arm))
            if row:
                lines.append(f"| {row['task_id']} / {arm} | {row['executor_episodes']} | {row['review_episodes']} | "
                             f"{row['requests']} | {row['input_tokens']} / {row['output_tokens']} | {row['last_online_verdict'] or '无'} |")
    false_accepts = sum(row["false_online_acceptance"] for row in summary["rows"])
    continued = sum(row["executor_episodes"] > 1 for row in summary["rows"])
    lines += ["", f"已观察到 {continued} 个试次执行超过一轮；{false_accepts} 个试次的在线 pass 与官方失败冲突。"
              "这两个计数描述已返回的数据，不能单独作为增益或可靠性证明。", "",
              "原生与完整 SG 的完整有效配对：`" + json.dumps(summary["paired_native_full"], ensure_ascii=False) + "`。"
              "以不同 task ID 为单位，不把模型调用数、审查次数或相同任务的不同组当成独立任务样本。", "",
              "## 解释边界", "",
              "- 官方参考解只验证环境和评分器，不属于任何模型组的成功。旧候选、装置失败和原始零分全部保留。",
              "- 这是开发样本，规模小、公开题目存在训练污染可能；不作显著性、通用性或跨天自治结论。",
              "- 在线审查器尚未完成独立校准。只读文件系统快照不保留服务进程，可能无法判断运行状态。",
              "- 此入口使用实际 v2 内核，但不等于生产网关插件端到端研究；生产默认引擎未切换。",
              "- 各组请求和时间上限相同，实际 token 用量不同；总输入 token 未设硬上限。",
              "- 评分前文件系统快照、完整模型轨迹和官方日志保留在 grok-bot；公开导出提供散列和必要评分日志。", "",
              "原始数据：[结果与评分日志](../experiments/results/public-benchmarks-2026-10-05.json)。"
              f"方法：[候选协议](../experiments/public_benchmarks/PUBLIC-{registration['experiment'].split('public-')[1].upper()}.md)、"
              f"[预登记](../experiments/public_benchmarks/registration-{registration['experiment']}.json)。", ""]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--registration", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    args = parser.parse_args()
    registration = json.loads(args.registration.read_text(encoding="utf-8"))
    summary = analyze(json.loads(args.bundle.read_text(encoding="utf-8")), registration)
    args.json_output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    args.markdown_output.write_text(markdown(summary, registration), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k not in {"rows", "apparatus_or_unresolved"}}))


if __name__ == "__main__":
    main()
