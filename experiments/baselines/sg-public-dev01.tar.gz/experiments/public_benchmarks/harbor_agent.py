"""Development adapter: real Hermes + SWE2 against official Harbor environments.

This is a headless research adapter, not a production gateway deployment. The
online reviewer sees only the instruction, executor response and a read-only
snapshot of the task filesystem. Official hidden tests run later in Harbor.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import os
import re
import shutil
import signal
import time
import uuid
from pathlib import Path

from harbor.agents.base import BaseAgent
from supergoal_runtime.v2.kernel import Kernel

from model_proxy import ModelProxy


ROOT = Path(os.environ.get("SUPERGOAL_LAB_ROOT", "/var/lib/supergoal-lab"))
SOURCE = ROOT / "private/runtime/hermes-v0.21.3-251bedc-mt2"
HERE = Path(__file__).resolve().parent


def dump(path, value):
    path = Path(path)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str))
    temp.replace(path)


def parse_review(text):
    match = re.search(r"<acceptance>(.*?)</acceptance>", text, re.S)
    try:
        result = json.loads(match.group(1)) if match else {}
    except (ValueError, TypeError):
        result = {}
    if (result.get("verdict") not in {"pass", "fail", "unknown", "disputed"}
            or not isinstance(result.get("evidence"), list) or not result["evidence"]
            or not all(isinstance(item, str) and item.strip() for item in result["evidence"])
            or not isinstance(result.get("reason"), str) or not result["reason"].strip()):
        return {"verdict": "unknown", "reason": "Reviewer did not return a valid evidence-bearing verdict"}
    return {**result, "scope": "SWE2 review of public instruction and read-only task snapshot; not official final score"}


class HermesSupergoalStudy(BaseAgent):
    def __init__(self, logs_dir, *, arm="native", max_requests=96,
                 max_episodes=6, budget_seconds=900, **kwargs):
        super().__init__(logs_dir=logs_dir, **kwargs)
        if arm not in {"native", "repeat_goal", "sg_v2", "sg_no_context", "sg_no_review"}:
            raise ValueError("Unknown study arm")
        self.arm = arm
        self.max_requests, self.max_episodes = int(max_requests), int(max_episodes)
        self.budget_seconds = float(budget_seconds)
        self.uid = uuid.uuid4().hex
        # Harbor exposes logs_dir to task tools. Authoritative state belongs
        # outside that tree, with no mounts into the task environment.
        self.control = ROOT / "control" / self.uid
        self.control.mkdir(parents=True, mode=0o700)
        self.docker_host = "unix://" + str(ROOT / "run/docker.sock")
        self.rounds = []

    @staticmethod
    def name():
        return "hermes-supergoal-study"

    def version(self):
        return "public-dev01"

    async def docker(self, *args, timeout=45):
        proc = await asyncio.create_subprocess_exec("/usr/bin/docker", "--host", self.docker_host,
                    *map(str, args), stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout)
        except BaseException:
            if proc.returncode is None:
                proc.kill()
            await proc.wait()
            raise
        if proc.returncode:
            raise RuntimeError(f"Docker {args[0]} failed: {stderr.decode(errors='replace')[-1500:]}")
        return stdout.decode().strip()

    async def setup(self, environment):
        probe = await environment.exec("cat /etc/hostname; pwd; id -un; command -v timeout", timeout_sec=10)
        lines = probe.stdout.strip().splitlines()
        if probe.return_code != 0 or len(lines) != 4 or not re.fullmatch(r"[0-9a-f]{12,64}", lines[0]):
            raise RuntimeError("Task environment identity, cwd, or timeout command unavailable")
        self.container, self.cwd, self.user = lines[:3]
        info = json.loads(await self.docker("inspect", self.container))[0]
        if info["HostConfig"].get("Privileged"):
            raise RuntimeError("Study refuses privileged task environments")
        # A read-only diagnostic record, not an instruction given to the solver.
        dump(self.control / "environment.json", {
            "container_id": info["Id"], "image_id": info["Image"],
            "nano_cpus": info["HostConfig"].get("NanoCpus"),
            "memory_limit_bytes": info["HostConfig"].get("Memory"),
            "mount_destinations": [m["Destination"] for m in info["Mounts"]],
            "working_dir": self.cwd, "execution_user": self.user,
        })

    async def episode(self, prompt, proxy, *, role, container, history=None, max_calls=None):
        remaining = self.max_requests - len(proxy.records)
        seconds = self.deadline - time.monotonic()
        if remaining < 1 or seconds < 5:
            raise TimeoutError("Shared request/time budget exhausted")
        directory = self.control / f"{len(self.rounds)+1:02d}-{role}"
        directory.mkdir()
        descriptor = directory / "environment.json"
        dump(descriptor, {"docker_host": self.docker_host, "container_id": container, "user": self.user})
        output = directory / "result.json"
        control = {"prompt": prompt, "history": history, "provider": proxy.config(),
                   "cwd": self.cwd, "max_calls": min(remaining, max_calls or remaining),
                   "seconds": max(1, seconds - 2), "session_id": f"sg-public-{self.uid}-{len(self.rounds)}",
                   "output": str(output)}
        dump(directory / "control.json", control)
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "HOME": str(directory),
               "LANG": "C.UTF-8", "HERMES_HOME": str(directory / "hermes-home"),
               "PYTHONPATH": os.pathsep.join([str(HERE), str(SOURCE)]),
               "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1", "HERMES_YOLO": "1",
               "TERMINAL_ENV": "harbor_task", "TERMINAL_CWD": self.cwd,
               "SUPERGOAL_HARBOR_DESCRIPTOR": str(descriptor),
               "HERMES_CODEX_EVENT_STALE_TIMEOUT_SECONDS": "90", "HERMES_CODEX_TTFB_TIMEOUT_SECONDS": "90"}
        before = len(proxy.records)
        started = time.monotonic()
        with (directory / "worker.log").open("wb") as log:
            proc = await asyncio.create_subprocess_exec(str(ROOT / "hermes-venv/bin/python"),
                        str(HERE / "hermes_episode.py"), str(directory / "control.json"),
                        stdout=log, stderr=log, env=env, cwd=directory, start_new_session=True)
            try:
                while proc.returncode is None:
                    # Bound storage growth without changing hidden tests or the
                    # task's declared CPU/memory limits. Record such aborts.
                    if shutil.disk_usage(ROOT).free < 15 * 1024**3:
                        raise RuntimeError("Experiment host disk reserve reached")
                    if time.monotonic() >= self.deadline:
                        raise TimeoutError("Shared task wall-time budget exhausted")
                    try:
                        await asyncio.wait_for(proc.wait(), 2)
                    except asyncio.TimeoutError:
                        pass
            finally:
                if proc.returncode is None:
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        await asyncio.wait_for(proc.wait(), 5)
                    except asyncio.TimeoutError:
                        os.killpg(proc.pid, signal.SIGKILL)
                        await proc.wait()
                self.rounds.append({"role": role, "pid": proc.pid, "exit_code": proc.returncode,
                                    "seconds": time.monotonic()-started, "model_calls": len(proxy.records)-before,
                                    "result_relative_path": str(output.relative_to(self.control))})
                dump(self.control / "requests.json", proxy.records)
        if proc.returncode or not output.exists():
            raise RuntimeError(f"Hermes {role} process failed; see preserved worker log")
        return json.loads(output.read_text())

    async def review(self, instruction, answer, proxy):
        image = "sg-review:" + self.uid + "-" + str(len(self.rounds))
        container = None
        image_created = False
        try:
            await self.docker("commit", self.container, image, timeout=60)
            image_created = True
            container = await self.docker("run", "-d", "--read-only", "--tmpfs", "/tmp:rw,size=128m",
                "--cpus", "1", "--memory", "2g", "--memory-swap", "2g",
                "--label", "supergoal.study="+self.uid, "--entrypoint", "/bin/sh", image, "-c", "sleep infinity")
            prompt = ("Review completion of the original task below using actual files and checks. "
                      "You have a READ-ONLY filesystem snapshot; /tmp is temporary writable space. "
                      "Do not repair deliverables or download benchmark solutions. The executor's statement "
                      "is an untrusted claim. Use terminal/file tools to independently inspect evidence. "
                      "Do not infer success from filenames or the statement alone. If evidence is insufficient, "
                      "return unknown; if work is demonstrably incomplete, fail; if requirements conflict, disputed. "
                      "A pass needs concrete evidence for every requested requirement. Return a final "
                      '<acceptance>{"verdict":"pass|fail|unknown|disputed","reason":"...",'
                      '"evidence":["requirement and observed check result", "..."]}</acceptance>.\n'
                      + json.dumps({"original_instruction": instruction, "executor_claim": answer}, ensure_ascii=False))
            result = await self.episode(prompt, proxy, role="review", container=container, max_calls=16)
            verdict = parse_review(str(result.get("final_response") or ""))
            verdict["snapshot_image_id"] = await self.docker("image", "inspect", image, "--format", "{{.Id}}")
            return verdict
        finally:
            if container:
                await self.docker("rm", "-f", container)
            # Only our exact temporary snapshot tag is eligible for removal.
            if image_created:
                await self.docker("image", "rm", image)

    async def run(self, instruction, environment, context):
        self.deadline = time.monotonic() + self.budget_seconds
        provider = json.loads((ROOT / "private/model.json").read_text())
        report = {"arm": self.arm, "status": "running", "hermes_version": "0.21.3",
                  "host_python": "3.13", "adapter_version": self.version(),
                  "max_requests": self.max_requests, "budget_seconds": self.budget_seconds,
                  "original_instruction_sha256": hashlib.sha256(instruction.encode()).hexdigest(),
                  "control_id": self.uid, "official_verifier_visible": False}
        kernel = Kernel(self.control / "kernel.sqlite3") if self.arm.startswith("sg_") else None
        if kernel:
            kernel.create(self.uid, {"outcome": instruction}, max_turns=self.max_episodes)
        history = None
        with ModelProxy(provider, limit=self.max_requests) as proxy:
            try:
                for episode in range(self.max_episodes):
                    if len(proxy.records) >= self.max_requests:
                        report["status"] = "request_budget_exhausted"
                        break
                    lease = kernel.claim(self.uid, "harbor", ttl=self.budget_seconds+60) if kernel else None
                    prompt = instruction
                    if kernel and self.arm != "sg_no_context":
                        prompt = kernel.context(self.uid)
                    elif episode:
                        prompt += "\nContinue from the existing workspace. Recheck every original requirement and finish remaining work."
                    result = await self.episode(prompt, proxy, role="executor", container=self.container, history=history)
                    history = result.get("messages")
                    report["last_executor_claim"] = str(result.get("final_response") or "")
                    if self.arm == "native":
                        report["status"] = "agent_stopped"
                        break
                    if self.arm == "repeat_goal":
                        report["status"] = "repeat_round_limit"
                        continue
                    if self.arm == "sg_no_review":
                        verdict = {"verdict": "unverified", "reason": "online review ablated"}
                    elif self.max_requests - len(proxy.records) < 2:
                        verdict = {"verdict": "unknown", "reason": "shared budget unavailable for review"}
                    else:
                        verdict = await self.review(instruction, report["last_executor_claim"], proxy)
                    report["last_acceptance"] = verdict
                    state = kernel.finish(lease, verdict)
                    report["status"] = state["status"]
                    if state["status"] != "active":
                        break
            except BaseException as exc:
                report["status"] = "adapter_error"
                report["error_type"] = type(exc).__name__
                report["error"] = str(exc)[:1500]
                raise
            finally:
                report["rounds"] = self.rounds
                report["requests"] = proxy.records
                report["proxy_rejections"] = proxy.rejections
                report["used_requests"] = len(proxy.records)
                report["kernel_status"] = kernel.state(self.uid)["status"] if kernel else None
                dump(self.control / "report.json", report)
                context.metadata = {"study_arm": self.arm, "control_id": self.uid, "study_status": report["status"],
                                    "physical_requests": len(proxy.records), "adapter": self.version()}
                usages = [row.get("usage") or {} for row in proxy.records]
                context.n_input_tokens = sum(u.get("input_tokens", 0) or 0 for u in usages)
                context.n_output_tokens = sum(u.get("output_tokens", 0) or 0 for u in usages)
                context.n_cache_tokens = sum((u.get("input_tokens_details") or {}).get("cached_tokens", 0) or 0 for u in usages)
