"""Recorded dependency-transport repair; does not edit task/tests or disable TLS/GPG."""

APT_HTTPS_BOOTSTRAP = r'''
from pathlib import Path
import hashlib, json
rows = []
for p in [Path('/etc/apt/sources.list'), *Path('/etc/apt/sources.list.d').glob('*')]:
    if p.is_file() and p.suffix in {'.list', '.sources'}:
        original = p.read_bytes()
        fixed = original.replace(b'http://deb.debian.org', b'https://deb.debian.org')
        if fixed != original:
            p.write_bytes(fixed)
            rows.append({'path': str(p), 'before_sha256': hashlib.sha256(original).hexdigest(),
                         'after_sha256': hashlib.sha256(fixed).hexdigest(),
                         'change': 'HTTPS transport only; package signatures unchanged'})
print(json.dumps(rows))
'''
