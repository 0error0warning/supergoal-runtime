"""Describe the registered public development sample without inflating its size."""

from __future__ import annotations

import argparse
from collections import Counter
import json
import math
from pathlib import Path
import random


def paired_statistics(counts):
    wins = counts.get('native_0_sg_1', 0)
    losses = counts.get('native_1_sg_0', 0)
    ties = counts.get('native_0_sg_0', 0) + counts.get('native_1_sg_1', 0)
    n, discordant = wins + losses + ties, wins + losses
    if not n:
        return {'paired_tasks': 0}
    p = min(1.0, 2 * sum(math.comb(discordant, k) for k in range(min(wins, losses)+1)) / 2**discordant) if discordant else 1.0
    differences = [1] * wins + [-1] * losses + [0] * ties
    rng = random.Random(20261006)
    samples = sorted(sum(rng.choices(differences, k=n))/n for _ in range(10000))
    return {'paired_tasks': n, 'sg_only_success': wins, 'native_only_success': losses,
            'success_rate_difference': (wins-losses)/n, 'mcnemar_exact_two_sided_p': p,
            'task_bootstrap_percentile_95': [samples[249], samples[9749]],
            'bootstrap_resamples': 10000, 'bootstrap_seed': 20261006,
            'bootstrap_degenerate': samples[249] == samples[9749],
            'scope': 'Conditional on available paired, deliberately selected task IDs. Not a population-generalization guarantee; resampling calls no model.'}


def analyze(bundle, registration):
    label = registration["experiment"]
    arms = registration["arms"]
    tasks = registration["tasks"]
    registered_tasks = {task["task_id"] for task in tasks}
    selected = {}
    errors = []
    for row in bundle["trials"]:
        result = row["result"]
        metadata = (result.get("agent_result") or {}).get("metadata") or {}
        if metadata.get("adapter") != label and not row["job_name"].startswith(f"tb-{label}-"):
            continue
        arm = metadata.get("study_arm") or (((result.get("config") or {}).get("agent") or {}).get("kwargs") or {}).get("arm")
        if arm not in arms:
            raise ValueError("Registered trial has no identifiable comparison arm")
        task_id = result["task_name"].removeprefix("terminal-bench/")
        if task_id not in registered_tasks:
            raise ValueError(f"Unregistered task identity: {result['task_name']}")
        key = (task_id, arm)
        if key in selected:
            raise ValueError(f"Duplicate registered task/arm; do not pick the best: {key}")
        control_id = metadata.get("control_id")
        report = (bundle["model_runs"].get(control_id) or {}).get("report") or {}
        grade = ((result.get("verifier_result") or {}).get("rewards") or {}).get("reward")
        acceptance = (report.get("last_acceptance") or {}).get("verdict")
        valid = row["classification"] == "graded"
        # Controller/worker errors belong to the system being evaluated. Keep
        # official reward untouched, but include these failures in end-to-end
        # completion instead of conditioning every comparison on successful runs.
        end_to_end = grade if valid else 0 if report.get("status") == "adapter_error" else None
        summary = {"task_id": key[0], "upstream_task_name": result["task_name"],
                   "arm": key[1], "classification": row["classification"],
                   "official_raw_reward": grade, "valid_for_comparison": valid,
                   "end_to_end_reward": end_to_end,
                   "requests": report.get("used_requests"), "status": report.get("status"),
                   "input_tokens": (result.get("agent_result") or {}).get("n_input_tokens"),
                   "output_tokens": (result.get("agent_result") or {}).get("n_output_tokens"),
                   "cache_tokens": (result.get("agent_result") or {}).get("n_cache_tokens"),
                   "executor_episodes": sum(r["role"] == "executor" for r in report.get("rounds", [])),
                   "review_episodes": sum(r["role"] == "review" for r in report.get("rounds", [])),
                   "review_verdicts": [r.get('verdict') for r in report.get('review_attempts', [])],
                   "episode_seconds": sum(r["seconds"] for r in report.get("rounds", [])),
                   "last_online_verdict": acceptance, "control_id": control_id,
                   "false_online_acceptance": valid and acceptance == "pass" and grade == 0,
                   "artifact_snapshot_available": bool(report.get("artifact_image_id"))}
        selected[key] = summary
        if not valid:
            errors.append(summary)
    paired = Counter()
    paired_end_to_end = Counter()
    for task in tasks:
        native, full = selected.get((task["task_id"], "native")), selected.get((task["task_id"], "sg_v2"))
        if native and full and native["valid_for_comparison"] and full["valid_for_comparison"]:
            paired[f"native_{native['official_raw_reward']:g}_sg_{full['official_raw_reward']:g}"] += 1
        if (native and full and native["end_to_end_reward"] is not None
                and full["end_to_end_reward"] is not None):
            paired_end_to_end[f"native_{native['end_to_end_reward']:g}_sg_{full['end_to_end_reward']:g}"] += 1
    return {"experiment": label, "collected_at": bundle["collected_at"],
            "host": bundle.get("host", "grok-bot"),
            "planned_tasks": len(tasks), "planned_arms": len(arms), "planned_trials": len(registration["planned_order"]),
            "observed_trials": len(selected), "valid_trials": sum(r["valid_for_comparison"] for r in selected.values()),
            "raw_trial_count_including_oracles_and_prior_candidates": len(bundle["trials"]),
            "paired_native_full": dict(paired), "apparatus_or_unresolved": errors,
            "paired_native_full_end_to_end": dict(paired_end_to_end),
            "paired_statistics_official": paired_statistics(paired),
            "paired_statistics_end_to_end": paired_statistics(paired_end_to_end),
            "end_to_end_by_arm": {arm: {
                "observed_evaluable_trials": sum(r["arm"] == arm and r["end_to_end_reward"] is not None for r in selected.values()),
                "successes": sum(r["arm"] == arm and r["end_to_end_reward"] == 1 for r in selected.values()),
                "controller_failures": sum(r["arm"] == arm and r["status"] == "adapter_error" for r in selected.values()),
            } for arm in arms},
            "mechanism_contrasts": mechanism_contrasts(list(selected.values()), registration.get('contrasts', [])),
            "rows": list(selected.values())}


def mechanism_contrasts(rows, contrasts):
    """Task-paired descriptive effects; never treat calls as sample units."""
    lookup = {(r['task_id'], r['arm']): r for r in rows}
    output = []
    for contrast in contrasts:
        control, treatment = contrast['control'], contrast['treatment']
        pairs = []
        for task in sorted({r['task_id'] for r in rows}):
            a, b = lookup.get((task, control)), lookup.get((task, treatment))
            if not a or not b or a['end_to_end_reward'] is None or b['end_to_end_reward'] is None:
                continue
            pairs.append({'task_id': task, 'reward_difference': b['end_to_end_reward']-a['end_to_end_reward'],
                          'request_difference': b['requests']-a['requests'] if a['requests'] is not None and b['requests'] is not None else None,
                          'second_episode_observed': max(a['executor_episodes'], b['executor_episodes']) > 1,
                          'unknown_audit_observed': 'unknown' in a.get('review_verdicts', []) or 'unknown' in b.get('review_verdicts', [])})
        output.append({**contrast, 'paired_tasks': len(pairs), 'pairs': pairs,
                       'mean_reward_difference': sum(p['reward_difference'] for p in pairs)/len(pairs) if pairs else None,
                       'interpretation': 'Exploratory, deliberately selected task units; activation subsets are descriptive and post-treatment.'})
    return output


def markdown(summary, registration):
    lookup = {(r["task_id"], r["arm"]): r for r in summary["rows"]}
    lines = [f"# Terminal-Bench 2.1 公开任务试验：{summary['experiment']}", "",
             f"收据截至 {summary['collected_at']}。已返回 {summary['observed_trials']}/{summary['planned_trials']} 个登记试次，"
             f"其中 {summary['valid_trials']} 个已完成官方测试。这是已登记子集，不是完整 Terminal-Bench 排行榜成绩。", "",
             f"执行器：{registration.get('executor_description', '真实 Hermes 0.21.3 + devin/swe-2')}。{len(registration['tasks'])} 个不同公开 task ID、"
             f"{len(registration['arms'])} 组，每组合一次；没有增加随机种子。全部审查、续跑和重试共享 "
             f"{registration.get('max_upstream_requests_per_trial')} 次上游请求及官方任务时间上限。"
             f"并发配置：`{json.dumps(registration.get('concurrency'), ensure_ascii=False)}`；保留各任务官方 CPU / 内存限额。"
             "容器内 Debian APT 改 HTTPS，Harbor 0.24.0，宿主 Python 3.13.5，环境差异已披露。", "",
             "## 官方结果", "", "未运行或尚无结果记为 —；缺少有效官方评分记为待审计。控制器/工作进程失败同时计入下方端到端失败，不能从分母中排除。", "",
             "| 任务 | " + " | ".join(registration['arms']) + " |",
             "|---|" + "---:|" * len(registration['arms'])]
    for task in registration["tasks"]:
        cells = []
        for arm in registration["arms"]:
            row = lookup.get((task["task_id"], arm))
            cells.append("—" if row is None else str(int(row["official_raw_reward"])) if row["valid_for_comparison"] else "待审计")
        lines.append("| " + " | ".join([task["task_id"], *cells]) + " |")
    lines += ["", "## 机制与实测用量", "",
              "| 任务 / 分组 | 执行轮次 | 审查轮次 | 实际请求 | 输入 / 输出 tokens | 在线终判 |",
              "|---|---:|---:|---:|---:|---|"]
    for task in registration["tasks"]:
        for arm in registration["arms"]:
            row = lookup.get((task["task_id"], arm))
            if row:
                lines.append(f"| {row['task_id']} / {arm} | {row['executor_episodes']} | {row['review_episodes']} | "
                             f"{row['requests']} | {row['input_tokens']} / {row['output_tokens']} | {row['last_online_verdict'] or '无'} |")
    false_accepts = sum(row["false_online_acceptance"] for row in summary["rows"])
    continued = sum(row["executor_episodes"] > 1 for row in summary["rows"])
    lines += ["", f"已观察到 {continued} 个试次执行超过一轮；{false_accepts} 个试次的在线 pass 与官方失败冲突。"
              "这两个计数描述已返回的数据，不能单独作为增益或可靠性证明。", "",
              "原生与完整 SG 的完整有效配对：`" + json.dumps(summary["paired_native_full"], ensure_ascii=False) + "`。"
              "以不同 task ID 为单位，不把模型调用数、审查次数或相同任务的不同组当成独立任务样本。", "",
              "端到端配对（包含控制器失败）：`" + json.dumps(summary["paired_native_full_end_to_end"], ensure_ascii=False) + "`。",
              "按 task ID 配对的统计：`" + json.dumps(summary['paired_statistics_end_to_end'], ensure_ascii=False) + "`。"
              "小样本或相同差值可能产生退化的 bootstrap 区间；它不是通用能力的置信保证。",
              "各组端到端统计：`" + json.dumps(summary["end_to_end_by_arm"], ensure_ascii=False) + "`。"
              "分母仅含已有可判定结果；待审计的评分装置问题与未启动试次单列。", "",
              "## 解释边界", "",
              "- 官方参考解只验证环境和评分器，不属于任何模型组的成功。旧候选、装置失败和原始零分全部保留。",
              "- 题目由项目选择，公开题目存在训练污染可能；结果不能单独证明通用性或跨天自治。开发与冻结后任务的划分见登记。",
              "- 在线审查器尚未完成独立校准。只读文件系统快照不保留服务进程，可能无法判断运行状态。",
              "- 此入口使用实际 v2 内核，但不等于生产网关插件端到端研究；生产默认引擎未切换。",
              "- 各组请求和时间上限相同，实际 token 用量不同；总输入 token 未设硬上限。",
              f"- 评分前文件系统快照、完整模型轨迹和官方日志保留在 {summary['host']}；公开导出提供散列和必要评分日志。", "",
              f"原始数据：[结果与评分日志](../experiments/results/{summary.get('bundle_file', 'public-benchmarks-2026-10-05.json')})。"
              f"方法：[候选协议]({registration.get('method_document', '../experiments/public_benchmarks/PUBLIC-' + registration['experiment'].removeprefix('public-').upper() + '.md')})、"
              f"[预登记](../experiments/public_benchmarks/registration-{registration['experiment']}.json)。", ""]
    if summary.get('mechanism_contrasts'):
        lines += ['## 已登记机制对照（开发样本，仅描述性）', '',
                  '```json', json.dumps(summary['mechanism_contrasts'], indent=2, ensure_ascii=False), '```', '']
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--registration", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    parser.add_argument("--markdown-output", type=Path, required=True)
    args = parser.parse_args()
    registration = json.loads(args.registration.read_text(encoding="utf-8"))
    summary = analyze(json.loads(args.bundle.read_text(encoding="utf-8")), registration)
    summary["bundle_file"] = args.bundle.name
    args.json_output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    args.markdown_output.write_text(markdown(summary, registration), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k not in {"rows", "apparatus_or_unresolved"}}))


if __name__ == "__main__":
    main()
