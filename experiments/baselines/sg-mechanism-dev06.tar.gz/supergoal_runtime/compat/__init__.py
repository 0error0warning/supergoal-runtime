"""Narrow host compatibility adapters."""
