# 新任务上的四框架对照：harness-transfer01

本协议在这三个任务的首次模型调用前固定。目标是检验开发阶段修复后的运行流程能否迁移到新任务，并比较真实上游 harness；不以证明 Supergoal 胜出为前提。

## 样本与登记顺序

固定 Terminal-Bench 源码 `7131e4375048a0e408a8fb404b5f499d726b695b`，选择三个不同任务：

| task ID | 上游类别 | 上游难度 | 求解 / 评分时限 | 每个任务容器 |
|---|---|---|---|---|
| adaptive-rejection-sampler | scientific-computing | medium | 900 / 900 秒 | 1 CPU、2 GiB |
| polyglot-rust-c | software-engineering | hard | 900 / 900 秒 | 1 CPU、2 GiB |
| gcode-to-text | file-operations | medium | 900 / 900 秒 | 1 CPU、2 GiB |

按资源、类别与未进入既有登记的条件刻意选择，不是从所有公开任务随机抽样，也不能保证模型训练时未见过。先固定 task ID 与完整文件散列，再各运行一次官方参考解；参考解失败的任务保留四个不可用单元，不用其他任务替换。

首次准备脚本发现 `cancel-async-tasks`、`db-wal-recovery` 已出现在更早的 `public-dev04` 登记，立即停止，未写入本次选题登记、未运行参考解或模型。原脚本、失败日志与原因保存在 `harness-transfer01-selection-abort01.json`；第二版选择上述名单。这个变更由登记重叠触发，未查看候选任务的模型成绩。

## 四个条件

每个任务各运行原生 Hermes、完整 Supergoal、上游 mini-SWE-agent、上游 LongHorizon 一次，总计十二个单元、三个统计单位。mini-SWE-agent 固定 `04d809ceab9df28f9adaed044884180159172930`；LongHorizon 固定 `a1dd930614972b92361c1b9cd6aac441a6db5a65`。框架循环使用对应上游源码，不在本项目重写一个近似版本。

全部使用 `devin/swe-2`。Hermes 固定 v0.21.3；mini 使用其原生执行循环和终端适配器；LongHorizon 使用上游支持的自定义 AgentAdapter，将每个角色接入 Hermes。LongHorizon 原始管理、执行、审查、格式修复和完成判定逻辑及提示保持不变，每个角色启动新的 Hermes 对话，使用上游选定的持久状态。

LongHorizon 的所有 CLI 角色共享同一个任务容器及终端/文件工具，沿用上游 Codex 后端的共享工作区范围；没有实现 Claude 后端专有的只读文件防护，也没有 GUI。该组应称为“LongHorizon + Hermes/SWE2 CLI 适配”，不能称为默认 Claude 配置、OSWorld 复现或论文榜单成绩。

四组使用同一份冻结的传输、容器定位与快照修复。Supergoal 审查时暂停执行容器，审查只读文件快照；LongHorizon 审查当前共享工作区。这是框架策略的实质差异，不能把结果简单解释为只有“是否多角色”不同。评分前不会向任何求解器提供隐藏测试或标准答案。

## 预算、顺序和资源

- 每次试验最多 192 次实际上游请求，包含执行、管理、审查、格式修复、SDK 重试和已预留但中断的请求；所有角色共享一份持久用量记录。每次输出上限 6,000 tokens，没有总输入 token 硬上限。
- 每个任务最多求解 900 秒；角色子时限受共同绝对截止时间限制。Supergoal 最多六轮外部执行；LongHorizon 最多六轮管理决策，每轮可包含多个角色调用。这两个“六轮”含义不同，主要可比约束是相同物理请求上限和时限。
- 固定交错顺序：四个周期中，对任务序号 t、周期 r，选条件 `(r+t) mod 4`；条件顺序为原生、SG、mini、LongHorizon。没有按先返回结果决定后续条件。
- 使用已完成机制实验释放的两个 CPU 槽位，最多并行两次；其他既有六 CPU 池不扩容。可用内存低于 10 GiB 或数据盘剩余低于 60 GiB 时停止接纳新任务。
- 不自动重做模型试次，不挑最高分，不追加同类随机种子。绝对云主机停机时间保持为 2026-10-06 14:24:06 UTC。

## 接入检查与冻结

LongHorizon 接入检查 `longhorizon-smoke01` 已使用真实上游循环、Hermes 和 SWE2 跑通管理 → 执行 → 审查 → 管理 → 最终答复，8 次物理请求，独立 JSON 文件检查通过。这是接入证据，不属于公开任务样本。

公开候选使用 `longhorizon-0.1.7-hermes-dev02`：相较 smoke 的 dev01，仅补充“快照恢复容器状态失败时，外层必须报告 adapter_error”的交接判定。七个本地边界测试覆盖 SDK 未完成却声称完成、请求/时间耗尽、GUI 不可用、取消传播、宿主文件边界及快照交接失败。实际上游成功路径与原 smoke 相同；失败路径有单独测试，旧 smoke 的源码与结果保持不变。

完整登记固定候选源码、三个任务文件树、参考解结果、初始镜像 ID、两个上游版本、顺序、预算和停止规则，模型运行前再核对。运行中的旧候选不改动；本批次不用于继续调参后再冒充冻结评估。

## 指标与解释

主要记录官方成功率及端到端完成情况，按 task ID 配对；另外记录实际请求、输入/输出 tokens、耗时、执行/审查/管理轮次、在线接受与官方评分冲突、服务故障、预算耗尽和快照交接失败。

三个任务只能提供描述性迁移证据。角色轮数、检查次数和十二个单元都不增加独立任务数。即使出现全胜，也不足以证明跨天自治或一般优越性。若多轮持续执行未触发，明确报告干预未激活。旧开发批次与本批次候选不同，不合并为同一随机对照。

原始失败、不可用任务及中断请求保留。网络/模型服务异常与求解错误分别诊断，但不事后删除不利结果。若服务错误导致流程失败，端到端失败仍保留，其能力归因单列。

依据：[LongHorizon 上游](https://github.com/AMAP-ML/LongHorizon-Harness/tree/a1dd930614972b92361c1b9cd6aac441a6db5a65)、[mini-SWE-agent 上游](https://github.com/SWE-agent/mini-swe-agent/tree/04d809ceab9df28f9adaed044884180159172930)。此前机制研究及其负结果见[机制协议](mechanism-study-2026-10-06.md)与[阶段性结论](research-findings-2026-10-06.md)。
